import { useState } from 'react'

function app(){

  return(
    <>
    <body>
        <div class="menu-container">
            <h1>Bem-vindo ao Jogo!</h1>
            <button onclick="startGame()">Iniciar Jogo</button>
            <button onclick="showSettings()">Configurações</button>
            <button onclick="exitGame()">Sair</button>
        </div>
        <script src="scripts.js"></script>
    </body>
    </>
  )
}

export default app